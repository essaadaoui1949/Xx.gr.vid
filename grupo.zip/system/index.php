YHAAA IDIOTTT








qinn enc; ASW77: $qinn = base64_decode("d3d3LnFpbm4ubXkuaWQgdGVtcGF0IGR3bmxvYWQgc2MgYW1hbiBqYXlhYSBwYXN0aW55YWFh=="); getfile JIeDF; mp6wH: $QINN_ENC =



/*

╔═══╗───────╔═══╗───────────╔╗
║╔═╗║───────║╔═╗║────╔╗────╔╝╚╗
║║─║╠╦═╗╔═╗─║╚═╝╠═╦══╬╬══╦═╩╗╔╝
║║─║╠╣╔╗╣╔╗╗║╔══╣╔╣╔╗╠╣║═╣╔═╣║
║╚═╝║║║║║║║║║║──║║║╚╝║║║═╣╚═╣╚╗
╚══╗╠╩╝╚╩╝╚╝╚╝──╚╝╚══╣╠══╩══╩═╝
───╚╝───────────────╔╝║
────────────────────╚═╝

*/


qinn enc; ASW77: $qinn = base64_decode("TFUgVEFVIEtPTlRPTEw/IA=="); getfile JIeDF; mp6wH: $QINN_ENC = "U2V0aWFwIG9yYW5nIHlhbmcgYmVyYWthbCBwYXN0aSBha2FuIHNlcGFrYXQgYmFod2EgbWVuY3VyaSBhZGFsYWggcGVyYnVhdGFuIHlhbmcgemFsaW0gZGFuIG1lcnVwYWthbiBrZWphaGF0YW4uIE9sZWgga2FyZW5hIGl0dSBJc2xhbSBqdWdhIG1lbmV0YXBrYW4gbGFyYW5nYW4gbWVuY3VyaSBoYXJ0YSBvcmFuZyBsYWluLiBCYWhrYW4gaWEgdGVybWFzdWsgZG9zYSBiZXNhciBkYW4ga2V6YWxpbWFuIHlhbmcgbnlhdGEuCgpTdW1iZXI6IGh0dHBzOi8vbXVzbGltLm9yLmlkLzQzMDU3LW1lbmN1cmktYWRhbGFoLWRvc2EtYmVzYXIuaHRtbA==";






















// please don't change my copyright
